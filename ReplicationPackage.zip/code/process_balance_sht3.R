# Last changed: 11/26/22
# Change Log: Adjusting deferred taxes to be net of 190 and 281-283 on the balance sheet.
# ------------------------------------------------------------------------------
# Load packages
if (!require("pacman")) {
  install.packages("pacman")
  library(pacman)
}

p_load(data.table, lubridate, tidyr, FinCal)
rm(list = ls())
# ------------------------------------------------------------------------------
# Set up for the loops
# Specify the form years to read in
years = c(seq.int(94, 99, 1), seq.int(0, 20, 1)) # 1994-2020

# ------------------------------------------------------------------------------
# Balance sheet 
# Two sheets = assets and liabilities 

# Create outer results and problem matrices
results.bal = list()
# ------------------------------------------------------------------------------
# Loop over filings
for (i in 1:length(years)) {
  this_year = years[i]
  print(this_year)
  
  # asset sheet
  balance.a = read.delim2(paste0("./data/raw/f1_comp_balance_db", this_year, ".txt"), header = TRUE, sep = ",")
  balance.a = as.data.table(balance.a)
  
  # keep end-of-year filings
  balance.a = balance.a[report_prd == 12,]
  
  # specify and select the needed rows and columns
  net_plant_row = if(this_year >= 4 & this_year <= 20) {14} else {10}
  deferred_tax_row = if(this_year >= 4 & this_year <= 20) {82} else if (this_year == 2 | this_year == 3) {68} else {66}
  column_with_values = if(this_year >= 4 & this_year <= 20) {"end_qtr_bal"} else {"end_yr_balance"}
  cols = c("respondent_id", "report_year", "row_number", column_with_values)
  
  balance.a = balance.a[row_number == net_plant_row | row_number == deferred_tax_row, mget(cols)]
  
  # change the row numbers to variable names
  balance.a$name = character(nrow(balance.a))
  balance.a[row_number == net_plant_row,"name"] = "net_plant_balance_r14"
  balance.a[row_number == deferred_tax_row, "name"] = "deferred_taxes"
  balance.a$row_number = NULL
  
  # There are three instances of duplicate observations in the asset data
  # Manually address the duplicates here
  # Instance 1: 2013, Respondent 7, five instances of net_plant and deferred taxes ----
    if (this_year == 13) {
      # specify problem id
      problem_id = 7 # APS
      
      # separate out problem utility from the non-duplicated data
      balance.a.prob = balance.a[respondent_id == problem_id]
      balance.a = balance.a[respondent_id != problem_id]
      
      # Using PDF, the first instance of each variable is correct
      balance.a.prob = balance.a.prob[c(1,2),]
      
      # Bind back
      balance.a = rbind(balance.a, balance.a.prob)
      
      # clean up
      rm(problem_id, balance.a.prob)
    }
  # Instance 2: 2018, Respondent 187, thirteen instances of net_plant and deferred taxes ----
  if (this_year == 18) {
    # specify problem id
    problem_id = 187 # Avista Corporation
    
    # separate out problem utility from the non-duplicated data
    balance.a.prob = balance.a[respondent_id == problem_id]
    balance.a = balance.a[respondent_id != problem_id]
    
    # Using PDF, the first instance of each variable is correct
    balance.a.prob = balance.a.prob[c(1,2),]
    
    # Bind back
    balance.a = rbind(balance.a, balance.a.prob)
    
    # clean up
    rm(problem_id, balance.a.prob)
  }
  # Instance 3: 2018, Respondent 170, fifteen instances of net_plant and five deferred taxes ----
  if (this_year == 18) {
    # specify problem id
    problem_id = 170 # Tampa Electric Company
    
    # separate out problem utility from the non-duplicated data
    balance.a.prob = balance.a[respondent_id == problem_id]
    balance.a = balance.a[respondent_id != problem_id]
    
    # Using PDF, the first instance of each variable is correct
    balance.a.prob = balance.a.prob[c(1,2),]
    
    # Bind back
    balance.a = rbind(balance.a, balance.a.prob)
    
    # clean up
    rm(problem_id, balance.a.prob)
  }
  
  # reshape the data in to wide form ----
  balance.a = as.data.table(pivot_wider(balance.a, names_from = "name", values_from = column_with_values))
  
  # liabilities
  balance.l = read.delim2(paste0("./data/raw/f1_bal_sheet_cr", this_year, ".txt"), header = TRUE, sep = ",")
  balance.l = as.data.table(balance.l)
  
  # keep end-of-year filings
  balance.l = balance.l[report_prd == 12,]
  
  # specify and subset the needed rows and columns
  deposits_row = if(this_year >= 4 & this_year <= 20) {41} else if (this_year == 2 | this_year == 3) {38} else {36}
  a281_row = if(this_year >= 4 & this_year <= 20) {62} else if (this_year == 2) {56} else if (this_year == 3) {57} else {53} # CHECK
  a282_row = if(this_year >= 4 & this_year <= 20) {63} else if (this_year == 2) {56} else if (this_year == 3) {57} else {53}
  a283_row = if(this_year >= 4 & this_year <= 20) {64} else if (this_year == 2) {56} else if (this_year == 3) {57} else {53}
  rows = c(deposits_row, a281_row, a282_row, a283_row)
  
  column_with_values = if(this_year >= 4 & this_year <= 20) {"end_qtr_bal"} else {"end_yr_balance"}
  cols = c("respondent_id", "report_year", "row_number", column_with_values)
  
  balance.l = balance.l[row_number %in% rows, mget(cols)]
  
  # There are four instances of duplicate observations in the liability data
  # Manually address the duplicates here
  # Instance 0: 2000, Respondent 189 ----
    if (this_year == 0) {
      # specify problem id
      problem_id = 189 # AEP Texas North Company
      
      # separate out problem utility from the non-duplicated data
      balance.l.prob = balance.l[respondent_id == problem_id]
      balance.l = balance.l[respondent_id != problem_id]
      
      # Using PDF, the first instance is correct
      balance.l.prob = balance.l.prob[1]
      
      # Bind back
      balance.l = rbind(balance.l, balance.l.prob)
      
      # clean up
      rm(problem_id, balance.l.prob)
    }
  # Instance 1: 2013, Respondent 7 ----
  if (this_year == 13) {
    # specify problem id
    problem_id = 7 # APS
    
    # separate out problem utility from the non-duplicated data
    balance.l.prob = balance.l[respondent_id == problem_id]
    balance.l = balance.l[respondent_id != problem_id]
    
    # Using PDF, the first instance is correct
    balance.l.prob = balance.l.prob[1]
    
    # Bind back
    balance.l = rbind(balance.l, balance.l.prob)
    
    # clean up
    rm(problem_id, balance.l.prob)
  }
  # Instance 2: 2018, Respondent 187 ----
  if (this_year == 18) {
    # specify problem id
    problem_id = 187 # Avista
    
    # separate out problem utility from the non-duplicated data
    balance.l.prob = balance.l[respondent_id == problem_id]
    balance.l = balance.l[respondent_id != problem_id]
    
    # Using PDF, the first instance is correct
    balance.l.prob = balance.l.prob[1]
    
    # Bind back
    balance.l = rbind(balance.l, balance.l.prob)
    
    # clean up
    rm(problem_id, balance.l.prob)
  }
  
  # Instance 3: 2018, Respondent 170 ----
  if (this_year == 18) {
    # specify problem id
    problem_id = 170 # Tampa
    
    # separate out problem utility from the non-duplicated data
    balance.l.prob = balance.l[respondent_id == problem_id]
    balance.l = balance.l[respondent_id != problem_id]
    
    # Using PDF, the first instance is correct
    balance.l.prob = balance.l.prob[1]
    
    # Bind back
    balance.l = rbind(balance.l, balance.l.prob)
    
    # clean up
    rm(problem_id, balance.l.prob)
  }
  
  # convert into wide format and combine columns as needed ----
    # Prior to 2004, accounts 281-283 were one row. For 2004-2020:
    if (this_year >= 4 & this_year <= 20) {
    balance.l = dcast(balance.l, respondent_id + report_year ~ row_number, value.var = column_with_values)
    setnames(balance.l, colnames(balance.l)[3:6], c("deposits", "a281", "a282", "a283"))
  
    # recode NA values to 0
    balance.l[is.na(deposits), "deposits"] = 0
    balance.l[is.na(a281), "a281"] = 0
    balance.l[is.na(a282), "a282"] = 0
    balance.l[is.na(a283), "a283"] = 0
    
    # sum accounts 281-283
    balance.l[, a281.83 := a281+a282+a283]
    balance.l[, `:=`(a281 = NULL, a282 = NULL, a283 = NULL)] # clean up
    } else {
    # Prior to 2004:
    balance.l = dcast(balance.l, respondent_id + report_year ~ row_number, value.var = column_with_values)
    setnames(balance.l, colnames(balance.l)[3:4], c("deposits", "a281.83"))
    }
  
  # merge the asset and liabilities tables ----
  balance = merge(balance.a, balance.l, all = TRUE, by = c("respondent_id","report_year"))
  
  # read in ID - Utility Name crosswalk (specific to each year) and merge on
  names = read.delim2(paste0("./data/raw/f1_respondent_id", this_year, ".txt"), 
                      header = TRUE, sep = ",")
  names = as.data.table(names)
  
  balance = merge(balance, names[,c("respondent_id", "respondent_name")], by = "respondent_id",
                  all.x = TRUE)
  
  # store results
  results.bal[[i]] = balance
}

# unlist
results.bal = do.call(rbind, results.bal)

# clean up
rm(balance.a, balance.l, 
   cols, column_with_values, deferred_tax_row, deposits_row,
   i, net_plant_row, this_year, balance)

# ------------------------------------------------------------------------------
# Save results
fwrite(results.bal, "./data/created/balance_sht.csv")
