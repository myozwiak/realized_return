# ------------------------------------------------------------------------------
# Load Packages
if (!require("pacman")) {
  install.packages("pacman")
  library(pacman)
}

p_load(data.table)
rm(list = ls())
# ------------------------------------------------------------------------------
# Read in data table with RMI authorized returns
dt = fread("./data/created/realized_return_iou_sample_andrmi.csv")

# ------------------------------------------------------------------------------
# Read in the plant in service sheet for 2020
# Note: I only exported this sheet for 2015-2020, because I didn't need the detailed information in the end
# So I'll just include a statistic for 2020, which I think is sufficient
plant = fread("./data/raw/f1_plant_in_srvce20.txt")

# Transmission investment will be row 58 (Total Transmission investment)
trans = plant[row_number == 58 & report_prd == 12] # end of year values

# Add transmission investment to the master table
dt.rmi = merge(dt[rmi.complete == T & report_year == 2020], 
               trans[, c("respondent_id", "yr_end_bal")],
               by = "respondent_id",
               all.x = T)
setnames(dt.rmi, "yr_end_bal", "trans_plant")

# Recode NA's to 0's (no transmission plant)
nrow(dt.rmi[is.na(trans_plant)]) # 7 utilities
dt.rmi[is.na(trans_plant), "trans_plant"] = 0

# Transmission share of plant
dt.rmi[, trans.share := trans_plant / plant_ln13]
mean(dt.rmi$trans.share) # 0.1582053
