# Data Source: https://utilitytransitionhub.rmi.org/finances/
# ------------------------------------------------------------------------------
# Load Packages
if (!require("pacman")) {
  install.packages("pacman")
  library(pacman)
}

p_load(data.table)
rm(list = ls())
# ------------------------------------------------------------------------------
# Read in table with authorized returns:
rmi = fread("./data/raw/rmi_debt_equity_returns.csv")
setorder(rmi, year)

# Read in realized ROR table
dt = fread("./data/created/realized_return_iou_sample.csv")
# ------------------------------------------------------------------------------
# In RMI's methodology, they use either data from a rate case or the mean across other utilities
# I want to flag when a value is the mean, rather than a utility-specific value 
# This will be, implicitly, the value that repeats the most in each year
  # Note that: simply repeating is insufficient, as there can be subsidiary utilities with equivalent returns
rmi[, times := .N, by = c("year", "ROR")]

# Rename the ROR variable
setnames(rmi, c("ROR"), c("rmi.authorized.ror"))

# Create flag if the value is implicitly the average
rmi[, max.N := max(times), by = year]
rmi[, rmi.used.avg := max.N == times]

# ------------------------------------------------------------------------------
# Add mean authorized ROR from RMI to the realized ROR table
dt = merge(dt, rmi[, c("year", "respondent_id", "rmi.authorized.ror", "rmi.used.avg")], 
           by.x = c("report_year", "respondent_id"), 
           by.y = c("year", "respondent_id"),
           all.x = T)

# Limit to utilities for which there is a unique value for all RMI years, 2005-2020
rmi.complete = dt[rmi.used.avg == F, .(years = .N), by = respondent_id]
nrow(rmi.complete[years == 16]) # 94 utilities
rmi.complete = rmi.complete[years == 16]
dt[, rmi.complete := (respondent_id %in% rmi.complete$respondent_id)]

# ------------------------------------------------------------------------------
# Save the file
fwrite(dt, "./data/created/realized_return_iou_sample_andrmi.csv")
