## Build tables from sheets within FERC Form 1
  # Income Statement 
  source("./code/process_income2.R")

  # Utility Plant Summary
  source("./code/process_plant_summary2.R")

  # Balance Sheet (Assets and Liabilities)
  source("./code/process_balance_sht3.R")

# Combine the data from each sheet into a master table
  source("./code/merge_sheets.R")
  
## Calculate the realized rate of return for investor-owned utilities
  source("./code/calculate_ROR4.R")
  
  # Add the authorized returns from RMI for 2005-2020
  source("./code/add_RMI_authorized_returns2.R")
  
## Make graphs and tables:
  # No specification on figure size -- ggplot will default to last viewer size:
  source("./code/make_ROR_graphs2.R")
  source("./code/assess_recovery.R") # Authorized vs. realized for RMI sub-sample
    
  # Check: What is mean exposure to transmission investment?
  # Cited in Footnote 19
    source("./code/check_transmission_share_rb_in_rmi_sample.R")
  
## Make appendix table for ROR
  source("./code/make_appendix_table.R")
  