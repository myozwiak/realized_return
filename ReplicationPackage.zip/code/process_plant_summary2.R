# Last Changed: 7.1.22
# Change Log: Use `tot_in_service` column, instead of `accum_prvsn_dad`
  # Values are equivalent in the form, but the former column is populated more frequently
# ------------------------------------------------------------------------------
# Load packages
if (!require("pacman")) {
  install.packages("pacman")
  library(pacman)
}

p_load(data.table, lubridate, tidyr, FinCal)
rm(list = ls())
# ------------------------------------------------------------------------------
# Set up for the loops
# Specify the form years to read in
years = c(seq.int(94, 99, 1), seq.int(0, 20, 1)) # 1994-2020

# ------------------------------------------------------------------------------
#  Utility Plant Summary
# two notes on utility plant summary:
# (1) The layout of the file is different. Variables are named.
# (2) The plant values here are slightly different from the balance sheet. These exclude nuclear.

# create data frames to store data from each year
results.plant = data.table(respondent_id = integer(0),
                           report_year = integer(0),
                           plant_ln8 = numeric(0),
                           plant_ln13 = numeric(0),
                           accum_depr = numeric(0),
                           respondent_name = character(0))

# ------------------------------------------------------------------------------
# loop over filings 
for (i in 1:length(years)) {
  this_year = years[i] # extract the year
  
  plant = read.delim2(paste0("./data/raw/f1_utltyplnt_smmry", this_year, ".txt"), header = TRUE, sep = ",")
  plant = as.data.table(plant)
  
  # keep end-of-year filings
  plant = plant[report_prd == 12,]
  
  # in the plant summary, the columns are named variables
  # keep row 1 = company total, and plant and depreciation values
  plant = plant[row_number == 1,c("respondent_id", "report_year", "in_srvc_total", "tot_utlty_plant", "tot_in_service")]
  
  # rename
  setnames(plant, c("in_srvc_total", "tot_utlty_plant", "tot_in_service"),
           c("plant_ln8", "plant_ln13", "accum_depr"))
  
  # there are three instances of duplicated rows in my time frame
  # manually address the duplicates here
  # Instance 1: 1998, ID 238 ----
    if (this_year == 98) {
      # specify problem id
      problem_id = 98
      
      # separate out problem utility from the non-duplicated data
      plant.prob = plant[respondent_id == problem_id]
      plant = plant[respondent_id != problem_id]
      
      # rows are identical, keep the first instance
      plant.prob = plant.prob[c(1),]
      
      # Bind back
      plant = rbind(plant, plant.prob)
      
      # clean up 
      rm(problem_id, plant.prob)
    }
  
  # Instance 2: 2004, ID 45 ----
    if (this_year == 98) {
      # specify problem id
      problem_id = 45
      
      # separate out problem utility from the non-duplicated data
      plant.prob = plant[respondent_id == problem_id]
      plant = plant[respondent_id != problem_id]
      
      # check PDF
      # Second row is correct
      plant.prob = plant.prob[c(2),]
      
      # Bind back
      plant = rbind(plant, plant.prob)
      
      # clean up 
      rm(problem_id, plant.prob)
    }
  
  # Instance 3: 2006, ID 285 ----
  if (this_year == 98) {
    # specify problem id
    problem_id = 285
    
    # separate out problem utility from the non-duplicated data
    plant.prob = plant[respondent_id == problem_id]
    plant = plant[respondent_id != problem_id]
    
    # rows are identical, keep the first
    plant.prob = plant.prob[c(1),]
    
    # Bind back
    plant = rbind(plant, plant.prob)
    
    # clean up 
    rm(problem_id, plant.prob)
  }
  # read in ID - Utility Name crosswalk (specific to each year) and merge on ----
  names = read.delim2(paste0("./data/raw/f1_respondent_id", this_year, ".txt"), 
                      header = TRUE, sep = ",")
  names = as.data.table(names)
  
  plant = merge(plant, names[,c("respondent_id", "respondent_name")], by = "respondent_id",
                  all.x = TRUE)
  
  # store results
  results.plant = rbind(results.plant, plant)
}

# clean up
rm(i, this_year, plant)

# ------------------------------------------------------------------------------    
# Save results
fwrite(results.plant, "./data/created/plant_sum.csv")