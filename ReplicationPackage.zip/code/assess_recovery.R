# This file looks at over- or under-recovery for the sub-sample for which RMI has a unique authorized return
# ------------------------------------------------------------------------------
# Load Packages
if (!require("pacman")) {
  install.packages("pacman")
  library(pacman)
}

p_load(haven, data.table, ggplot2, lubridate, tidyr)
rm(list = ls())
# ------------------------------------------------------------------------------
# Read in data 
dt = fread("./data/created/realized_return_iou_sample_andrmi.csv")

# ------------------------------------------------------------------------------
# Limit dt to only those utilities and years for which RMI has a unique authorized return
dt.r = dt[rmi.complete == T & report_year >= 2005] # data set begins in 2005

# How many utilities do we have in the sample? 
# Note: It's a balanced panel by construction
dt.r[, .(count = .N), by = report_year] # 94 utilities in the sub-sample

# Create a column to calculate difference between realized and authorized return
dt.r[, recovery := ror - rmi.authorized.ror]

# ------------------------------------------------------------------------------
# Calculate average realized, authorized and spread by year
ann.avg = dt.r[, .(ror_avg = mean(ror),
                ror_auth = mean(rmi.authorized.ror),
                recovery_avg = mean(recovery),
                sd = sd(ror),
                sd.authorized = sd(rmi.authorized.ror),
                sd.recovery = sd(recovery)),
             by = "report_year"]

# ------------------------------------------------------------------------------
# Make the plots:
  # I think I want this on one graph
  plot_all = ggplot(ann.avg, aes(x = report_year)) +
    geom_ribbon(aes(ymin = ror_avg - sd/2,
                    ymax = ror_avg + sd/2), alpha = 0.1) +
    geom_ribbon(aes(ymin = ror_auth - sd.authorized / 2,
                    ymax = ror_auth + sd.authorized/2), alpha = 0.1, fill = "blue") +
    geom_line(aes(y = ror_avg), size = 1.1) +
    geom_line(aes(y = ror_auth), size = 1.1, color = "blue") + 
    geom_ribbon(aes(ymin = recovery_avg - sd.recovery/2,
                    ymax = recovery_avg + sd.recovery/2), alpha = 0.1, fill = "red") +
    geom_line(aes(y = recovery_avg), size = 1.1, color = "red") + 
    theme_bw() +
    ylab("Return") +
    xlab("Year") + 
    geom_hline(yintercept = 0, size = 0.25) +
    scale_x_continuous(breaks = seq(2004,2020, by = 2)) +
    coord_cartesian(ylim = c(-0.04, 0.14)) +
    scale_y_continuous(breaks = seq(-0.04, 0.14, by = 0.02)) + 
    # Add manual labels
    geom_label(label="Realized Return", x=2018, y=0.05, label.padding = unit(0.25, "lines"), label.size = 0.25, color = "black") +
    geom_label(label="Authorized Return", x=2008, y=0.075, label.padding = unit(0.25, "lines"), label.size = 0.25, color = "blue") +
    geom_label(label="Realized - Authorized", x=2017, y=-0.02, label.padding = unit(0.25, "lines"), label.size = 0.25, color = "red")

  # Save the results:
  ggsave("./output/figure_3.png", plot = plot_all)

# ------------------------------------------------------------------------------
# Make a table of the annual average numbers for appendix:
  appendix <- dt.r[, .(ror_avg = mean(ror),
                      ror_auth = mean(rmi.authorized.ror),
                      recovery_avg = mean(recovery),
                      median = median(recovery),
                      percentile.25 = quantile(recovery, 0.25),
                      percentile.75 = quantile(recovery, 0.75)),
                      by = "report_year"] # Align with the prior table
  
  appendix[, `:=`(ror_avg = round(ror_avg * 100, 2),
                  ror_auth = round(ror_auth * 100, 2),
                  recovery_avg = round(recovery_avg * 100, 2),
                  median = round(median * 100, 2),
                  percentile.25 = round(percentile.25 * 100, 2),
                  percentile.75 = round(percentile.75 * 100, 2))]
  
  write.table(appendix, 
             sep = ",", row.names = F, file = "./output/appendix_table2.txt")
# ------------------------------------------------------------------------------
# Pull out numbers that I need
  ann.avg[report_year == 2005] # 10.8% realized return
  mean(dt[report_year == 2005]$ror) # 0.09405821 for the full sample
  
  ann.avg[report_year == 2005 | report_year == 2020] # 0.08630013 to 0.07311146
  
# Count: How many of the utilities under-recover by year?
  dt.r[, .(under = sum(recovery < 0)), by = report_year]
  
# How representative is the subset?
  length(unique(dt.r$State)) # 42 states
  
  total.subset.rb = dt.r[, .(subset.rate_base = sum(rate_base)), by = report_year]
  all.rb = dt[, .(all.rate_base = sum(rate_base)), by = report_year]
  compare.rb = merge(total.subset.rb, all.rb, by = "report_year", all.x = T)
  compare.rb[, share := subset.rate_base / all.rate_base]
  mean(compare.rb$share) # 0.7696061
  