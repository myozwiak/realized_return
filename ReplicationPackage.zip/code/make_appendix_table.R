# ------------------------------------------------------------------------------
# Load Packages
if (!require("pacman")) {
  install.packages("pacman")
  library(pacman)
}

p_load(data.table)
rm(list = ls())
# ------------------------------------------------------------------------------
# Read in ROR table
dt = fread("./data/created/realized_return_iou_sample.csv")

# ------------------------------------------------------------------------------
# Make the appendix table
# Display values in $ Thousands
appendix = list()
years = unique(dt$report_year)
for (i in 1:length(years)) {
  this.year = years[i]
  revenue = mean(dt[report_year == this.year]$revenue) / 1000
  
  rate_base = mean(dt[report_year == this.year]$rate_base) / 1000
  plant_ln13 = mean(dt[report_year == this.year]$plant_ln13) / 1000
  deposits = mean(dt[report_year == this.year]$deposits) / 1000
  edit = mean(dt[report_year == this.year]$edit)/ 1000
  accum_depr = mean(dt[report_year == this.year]$accum_depr)/ 1000
  
  expense = mean(dt[report_year == this.year]$expense)/ 1000
  operation_exp = mean(dt[report_year == this.year]$operation_exp)/ 1000
  maintenance_exp = mean(dt[report_year == this.year]$maintenance_exp)/ 1000
  depr_exp = mean(dt[report_year == this.year]$depr_exp)/ 1000
  amort_exp = mean(dt[report_year == this.year]$amort_exp)/ 1000
  net_taxes = mean(dt[report_year == this.year]$net_taxes)/ 1000
  
  ror = mean(dt[report_year == this.year]$ror)
  ror.median = median(dt[report_year == this.year]$ror)
  ror.25 = as.numeric(quantile(dt[report_year == this.year]$ror, 0.25))
  ror.75 = as.numeric(quantile(dt[report_year == this.year]$ror, 0.75))
  
  appendix[[i]] = data.table(this.year, revenue, rate_base, plant_ln13, deposits, edit, accum_depr, expense, operation_exp, maintenance_exp, depr_exp, amort_exp, net_taxes, ror, ror.median, ror.25, ror.75)
}

appendix = do.call(rbind, appendix)

# Make EDIT positive
appendix$edit = appendix$edit * -1

# ------------------------------------------------------------------------------
# Save the result
fwrite(appendix, "./output/appendix_table.csv")
