# ------------------------------------------------------------------------------
# Load Packages
if (!require("pacman")) {
  install.packages("pacman")
  library(pacman)
}

p_load(haven, data.table, ggplot2, lubridate, tidyr)
rm(list = ls())
# ------------------------------------------------------------------------------
# Read in data 
dt = fread("./data/created/realized_return_iou_sample.csv")

# ------------------------------------------------------------------------------
# Mean return and standard deviation by year

# Check that there are no NA's in the estimated ROR
nrow(dt[is.na(ror)]) # good.

# Simple average
  ann.avg = dt[, .(ror_avg = mean(ror),
                   ror_median = median(ror),
                   sd = sd(ror)),
               by = "report_year"]
  
  plot_simple.avg = ggplot(ann.avg, aes(x = report_year)) +
    geom_ribbon(aes(ymin = ror_avg - sd/2,
                    ymax = ror_avg + sd/2), alpha = 0.2) +
    geom_line(aes(y = ror_avg), size = 1.1) +
    theme_bw() +
    ylab("Realized Rate of Return") +
    xlab("Year") +
    coord_cartesian(ylim = c(0, 0.15)) + 
    scale_y_continuous(breaks = seq(0, 0.15, by = 0.02)) +
    scale_x_continuous(breaks = seq(1994, 2020, by = 2)) # 600 x 450
  
  # Save the file:
  ggsave("./output/figure_1a.png", plot = plot_simple.avg)
  
  # graph of median for appendix
  median = ggplot(ann.avg, aes(x = report_year)) +
    geom_line(aes(y = ror_avg), size = 1.1) + 
    geom_line(aes(y = ror_median), size = 1.1, color = "blue") +
    theme_bw() +
    ylab("Realized Rate of Return") +
    xlab("Year") +
    coord_cartesian(ylim = c(0, 0.15)) + 
    scale_y_continuous(breaks = seq(0, 0.15, by = 0.02)) +
    scale_x_continuous(breaks = seq(1994, 2020, by = 2))
  
# Weighted average (using share of the rate base)
  # Calculate the total rate base across all utilities in each year
    total_rb = dt[, .(total_rb = sum(rate_base)), by = "report_year"]
    # merge the variable back onto dt
    dt = merge(dt, total_rb, by = "report_year")
    #clean up
    rm(total_rb)
  
  # Calculate each company's share 
  dt[, share_rb := rate_base / total_rb]
  
  # Use shares to calculate a weighted mean by year
  ann.avg_w = dt[, .(ror_avg_w = weighted.mean(ror, w = share_rb)),
                 by = "report_year"]
  
  # Calculate the standard deviation by hand
    # merge the weighted average variable onto dt
    dt = merge(dt, ann.avg_w, by = "report_year")
    # calculate the variance
    dt[, var_w := share_rb * (ror - ror_avg_w)^2]
    # re-collapse to the national time series
    ann.avg_w = dt[, .(ror_avg_w = weighted.mean(ror, w = share_rb),
                       var_w = sum(var_w)),
                   by = "report_year"]
    # take the square root of the variance
    ann.avg_w[, sd_w := sqrt(var_w)]
    # clean up
    dt$var_w = NULL
    dt$ror_avg_w = NULL
    dt$total_rb = NULL
      # keep the share_rb -- it's a nice diagnostic
    
  # Make the plot
  plot_weighted.avg = ggplot(ann.avg_w, aes(x = report_year)) +
    geom_ribbon(aes(ymin = ror_avg_w - sd_w/2,
                    ymax = ror_avg_w + sd_w/2), alpha = 0.2) +
    geom_line(aes(y = ror_avg_w), size = 1.1) +
    theme_bw() +
    ylab("Realized Rate of Return") +
    xlab("Year") +
    coord_cartesian(ylim = c(0, 0.15)) + 
    scale_y_continuous(breaks = seq(0, 0.15, by = 0.02)) +
    scale_x_continuous(breaks = seq(1994, 2020, by = 2)) # Save: 600 x 450
  
  ggsave("./output/figure_1b.png", plot = plot_weighted.avg)
  
# ------------------------------------------------------------------------------
# Show how the rate base components have evolved over time

  # calculate mean values by year
  parts = dt[, .(avg_rev = mean(revenue),
                 avg_exp = mean(expense),
                 avg_rb = mean(rate_base)),
             by = "report_year"]
  
  # Deflate the values to $1994
    # Read in BLS CPI-U inflation series:
    inflation = fread("./data/raw/inflation.csv") # Source: https://data.bls.gov/cgi-bin/surveymost
      # CPI-U, all items, all cities, U.S. city average
      # Annual value
      # Series ID: CUUR0000SA0
      # Factor is calculated following: https://www.bls.gov/cpi/factsheets/cpi-math-calculations.pdf

    # Add factor to convert $ nominal to $ 1994 to parts
    parts = merge(parts, inflation[, c("Year", "Factor_1994")],
                  all.x = TRUE,
                  by.x = "report_year",
                  by.y = "Year")
    
    # Convert means to real values
    parts[, `:=`(avg_rev.r = avg_rev * Factor_1994,
                 avg_exp.r = avg_exp * Factor_1994,
                 avg_rb.r = avg_rb * Factor_1994)]
  
  # Index to 1994 values
  revenue_94 = parts[report_year == 1994]$avg_rev.r
  expense_94 = parts[report_year == 1994]$avg_exp.r
  rb_94 = parts[report_year == 1994]$avg_rb.r
  
  # Convert the absolute means to percent of the starting value in 1994
  parts[, `:=` (indexed_rev = avg_rev.r / revenue_94,
                indexed_exp = avg_exp.r / expense_94,
                indexed_rb = avg_rb.r / rb_94)]
  
  # Make the plot
  plot_ror.parts = ggplot(parts, aes(x = report_year)) +
    geom_line(aes(y = indexed_rev), linetype = "longdash", size = 1.05) +
    geom_line(aes(y = indexed_exp), linetype = "dotted", color = "blue", size = 1.05) +
    geom_line(aes(y = indexed_rb), linetype = "solid", color = "red", size = 1.05) +
    theme_bw() +
    ylab("Mean of Realized Return Components (% of 1994)") +
    xlab("Year") +
    scale_x_continuous(breaks = seq(1994, 2020, by = 2))
  
  ggsave("./output/figure_4a.png", plot = plot_ror.parts)
  
  # Exact values for text
  parts[report_year == 2020, "indexed_rb"] # 1.991787
  parts[report_year == 2020, "indexed_exp"] # 0.9878744
  parts[report_year == 2020, "indexed_rev"] # 1.00123
  
  # Repeat with nominal values for appendix
  parts[, `:=` (indexed_rev.n = avg_rev / revenue_94,
                indexed_exp.n = avg_exp / expense_94,
                indexed_rb.n = avg_rb / rb_94)]
  
  plot_ror.parts.n = ggplot(parts, aes(x = report_year)) +
    geom_line(aes(y = indexed_rev.n), linetype = "longdash", size = 1.05) +
    geom_line(aes(y = indexed_exp.n), linetype = "dotted", color = "blue", size = 1.05) +
    geom_line(aes(y = indexed_rb.n), linetype = "solid", color = "red", size = 1.05) +
    theme_bw() +
    ylab("Mean of Realized Return Components (% of 1994)") +
    xlab("Year") +
    scale_x_continuous(breaks = seq(1994, 2020, by = 2))
  
  ggsave("./output/figure_4b.png", plot = plot_ror.parts.n)
  
# ------------------------------------------------------------------------------
# Look at regional variation
  # Manually code states to general regions (wholesale market boundaries naturally changed over time)
  # Source: https://www.eia.gov/consumption/commercial/maps.php#census
  dt[, `:=`(division = "XX", region = "XX")]
    dt[State %in% c("WA", "OR", "CA", "AK", "HI"), `:=`(division = "Pacific", region = "West")]
    dt[State %in% c("MT", "ID", "WY", "NV", "UT", "CO", "AZ", "NM"), `:=`(division = "Mountain", region = "West")]
    dt[State %in% c("TX", "OK", "AR", "LA"), `:=`(division = "West South Central", region = "South")]
    dt[State %in% c("KY", "TN", "MS", "AL"), `:=`(division = "East South Central", region = "South")]
    dt[State %in% c("FL", "GA", "SC", "NC", "VA", "WV", "DC", "MD", "DE"), `:=`(division = "South Atlantic", region = "South")]
    dt[State %in% c("ND", "SD", "NE", "KS", "MN", "IA", "MO"), `:=`(division = "West North Central", region = "Midwest")]
    dt[State %in% c("WI", "IL", "IN", "MI", "OH"), `:=`(division = "East North Central", region = "Midwest")]
    dt[State %in% c("NY", "PA", "NJ"), `:=`(division = "Middle Atlantic", region = "Northeast")]
    dt[State %in% c("VT", "CT", "RI", "MA", "NH", "ME"), `:=`(division = "New England", region = "Northeast")]
  
  
  # Collapse to the averages by division
  ann.avg_division = dt[, .(ror_avg = mean(ror),
                          sd = sd(ror),
                      region = first(region)), by = c("report_year", "division")]
  ann.avg_division$division <- factor(ann.avg_division$division,
                                      levels = c("West North Central", "East North Central",
                                                 "New England", "Middle Atlantic", 
                                                 "South Atlantic", "East South Central", "West South Central", 
                                                 "Mountain", "Pacific")) # For facet_wrap
  
  # Make a plot
  plot_region = ggplot(ann.avg_division, aes(x = report_year)) +
    geom_line(aes(y = ror_avg, color = region), linewidth = 1.1) +
    geom_ribbon(aes(ymin = ror_avg - sd/2, ymax = ror_avg + sd/2,
                    fill = region), alpha = 0.2) +
    theme_bw() +
    coord_cartesian(ylim = c(0, 0.15)) +
    ylab("Realized Rate of Return") +
    xlab("Year") +
    labs(fill = "Census Region", color = "Census Region") +
    facet_wrap(facets = "division")
  
  ggsave("./output/figure_2.png", plot = plot_region)
  
  

  
  
  