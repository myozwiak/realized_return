# ------------------------------------------------------------------------------
# Load Packages
if (!require("pacman")) {
  install.packages("pacman")
  library(pacman)
}

p_load(haven, data.table, ggplot2, lubridate, tidyr)
rm(list = ls())
# ------------------------------------------------------------------------------
# Read in FERC Form 1 data
dt = fread("./data/created/master_FF1_table_for_ROR.csv")

# Read in index of utilities that are investor-owned, using manually-created FERC-EIA 861 crosswalk
index_iou = fread("./data/created/subset_ferc_on_eia_info_7-21-22.csv", header = TRUE)

# ------------------------------------------------------------------------------
# Subset the data:

# Select investor-owned utilities
  # Excludes: cooperatives, transmission companies, generation companies, entities without names / unable to be verified.
  dt.iou = dt[dt$respondent_id %in% index_iou$respondent_id]

    # Check: How many companies does this exclude?
    length(unique(dt$respondent_id)) # 358
    length(unique(dt.iou$respondent_id)) # 177 -- 181 companies removed
  
# Drop filings in years where utilities exit, change type, underwent restructuring, or merged
    # See the list of utilities it applies to
    index_iou[!(is.na(Cutoff_Year_Exclusive)) | !(is.na(Beginning_Year_Inclusive)),] # 6 companies
    
    # Drop observations as needed
    dt.iou = dt.iou[!(respondent_id == 29 & report_year >= 2000),] # Merged into a telephone company
    dt.iou = dt.iou[!(respondent_id == 35 & report_year >= 2005),] # Became a wholesale power marketer in 2005+
    dt.iou = dt.iou[!(respondent_id == 63 & report_year >= 2015),] # Merged into Entergy Louisiana
    dt.iou = dt.iou[!(respondent_id == 66 & report_year >= 2008),] # Acquired by municipality
    dt.iou = dt.iou[!(respondent_id == 158 & report_year >= 2008),] # Acquired by Alliant
    dt.iou = dt.iou[!(respondent_id == 454 & report_year < 2015),] # Switch from ID 87 in 2015

# ------------------------------------------------------------------------------
# Remove observations that reflect non-response by utilities
  # For the rate base:
    # It's conceivable that the utility does not have any deposits or deferred taxes
    # But 0 or missing values in plant or depreciation is an obvious issue (every utility in the sample should have both)
  
    # Check the number of observations to drop
    nrow(dt.iou[is.na(plant_ln13) | plant_ln13 == 0 | is.na(accum_depr) | accum_depr == 0]) # 19 observations
      # Checking these PDFs, these reflect non-response by the utilities.
      # Most of the instances occur in 1996. It might be partially an anomaly due to restructuring.
  
    # Drop filings without complete information for the plant or accumulated depreciation
    dt.iou = dt.iou[!is.na(plant_ln13) & plant_ln13 != 0 & !is.na(accum_depr) & accum_depr != 0]
  
  # For revenue:
    nrow(dt.iou[is.na(revenue)]) # 1 observation -- Southern Indiana Gas and Electric Company, ID 163 in 2018
    # In this instance, it is an issue in the FERC database -- the PDF has the revenue information populated
    # Hard code:
    dt.iou[respondent_id == 163 & report_year == 2018, "revenue"] = 682548730
    
  # For expense: Point of concern is operation and maintenance expenses
    nrow(dt.iou[is.na(operation_exp) | operation_exp == 0]) # 1 instance
    nrow(dt.iou[is.na(maintenance_exp) | maintenance_exp == 0]) # 20 instances
    
    # Checking PDFs: Most 0 or NA values reflect the response of the utility
    # Remove Entergy Arkansas, ID 8 in 1996 for nonresponse -- the company didn't populate the income sheet
    dt.iou = dt.iou[-(which(respondent_id == 8 & report_year == 1996))]
  
# ------------------------------------------------------------------------------ 
# Calculate the realized rate of return for each filing
  
  # Recode any remaining NA values to 0
  # An NA occurs if the utility did not have an value recorded for the variable
    dt.iou[is.na(deposits),"deposits"] = 0
    dt.iou[is.na(deferred_taxes),"deferred_taxes"] = 0
    dt.iou[is.na(accum_depr),"accum_depr"] = 0
    dt.iou[is.na(operation_exp),"operation_exp"] = 0
    dt.iou[is.na(maintenance_exp),"maintenance_exp"] = 0
    dt.iou[is.na(depr_exp),"depr_exp"] = 0
    dt.iou[is.na(amort_exp),"amort_exp"] = 0
    dt.iou[is.na(net_taxes),"net_taxes"] = 0
    dt.iou[is.na(a281.83),"a281.83"] = 0
    
  # Calculate the EDIT value: sum of (+190) - (a281.3)
    dt.iou[, edit := deferred_taxes - a281.83]
  
  # Calculate the rate base and expense components by year
  # Note that: Edit is now a negative (so it's added, in order to be a deduction)
  dt.iou[, `:=`(rate_base = plant_ln13 - deposits + edit - accum_depr,
                expense = operation_exp + maintenance_exp + depr_exp + amort_exp + net_taxes)]
  
  # Calculate the implicit return realized = (revenue - expense) / rate base
  dt.iou[, ror := (revenue - expense) / rate_base] 
  
# ------------------------------------------------------------------------------ 
# Add the state information to the master table
  dt.iou = merge(dt.iou, index_iou[, c("respondent_id", "State")], by = "respondent_id")
  
# ------------------------------------------------------------------------------
# Save the table
fwrite(dt.iou, "./data/created/realized_return_iou_sample.csv")
  