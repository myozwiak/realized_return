# Combine the data from the income, balance and plant summary sheets into one master table
# ------------------------------------------------------------------------------
# Load packages
if (!require("pacman")) {
  install.packages("pacman")
  library(pacman)
}

p_load(data.table)
rm(list = ls())
# ------------------------------------------------------------------------------
# Read in data
income = fread("./data/created/income_sheet.csv")
balance = fread("./data/created/balance_sht.csv")
plant = fread("./data/created/plant_sum.csv")
# ------------------------------------------------------------------------------
# Create master table
# Keep the respondent name from the income sheet
  # missings should only occur if a utility had balance / plant data, but no income
  balance$respondent_name = NULL
  plant$respondent_name = NULL
  
# Remove the NA row in the plant data
  plant = plant[!is.na(respondent_id)]

# Add balance sheet data to income  
master = merge(income, balance, by = c("respondent_id", "report_year"),
               all = TRUE)

# Add plant summary data
master = merge(master, plant, by = c("respondent_id", "report_year"),
               all = TRUE)
# ------------------------------------------------------------------------------
# Save the file
fwrite(master, "./data/created/master_FF1_table_for_ROR.csv")
