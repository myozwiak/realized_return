# ------------------------------------------------------------------------------
# Load packages
if (!require("pacman")) {
  install.packages("pacman")
  library(pacman)
}

p_load(data.table, lubridate, tidyr, FinCal)
rm(list = ls())
# ------------------------------------------------------------------------------
# Set up for the loops
# Specify the form years to read in
years = c(seq.int(94, 99, 1), seq.int(0, 20, 1)) # 1994-2020

# ------------------------------------------------------------------------------
# create data frames to store data from each year
results.inc = data.table(respondent_id = integer(0),
                         report_year = integer(0),
                         revenue = numeric(0),
                         net_op_inc = numeric(0),
                         operation_exp = numeric(0),
                         maintenance_exp = numeric(0),
                         depr_exp = numeric(0),
                         amort_exp = numeric(0),
                         net_taxes = numeric(0),
                         respondent_name = character(0))

# ------------------------------------------------------------------------------
# Loop over filings
for (i in 1:length(years)) {
  this_year = years[i] # extract the year
  
  # read in the data
  inc = read.delim2(paste0("./data/raw/f1_income_stmnt", this_year, ".txt"),
                    header = TRUE, sep = ",")
  inc = as.data.table(inc)
  
  # keep year-end (quarter 4) filings
  inc = inc[report_prd == 12,]
  
  # specify the observations to keep, based on the ROR calculation
  # variables are specified by row numbers that correspond to the PDF forms
  # these row numbers change over time, as the form is adjusted
  revenue_row = 2 # Account 400
  operation_exp_row = 4 # Account 401
  maintenance_exp_row = 5 # Account 402
  depr_exp1_row = 6 # Account 403
  depr_exp2_row = if(this_year >= 3 & this_year <= 20) {7} else {22} # Account 403.1 (after 2003)
  # note that: for years prior to 2003, this value will be 0'd out below -- row 22 is a temporary dummy
  # probably a better way but here we are
  amort_exp1_row = if(this_year >= 3 & this_year <= 20) {8} else {7} # Accounts 404-5
  amort_exp2_row = if(this_year >= 3 & this_year <= 20) {9} else {8} # Account 406
  amort_exp3_row = if(this_year >= 3 & this_year <= 20) {10} else {9} # Account 407
  amort_exp4_row = if(this_year >= 3 & this_year <= 20) {11} else {10} # Account 407
  taxes1_row = if(this_year >= 3 & this_year <= 20) {14} else {13} # Account 408.1
  taxes2_row = if(this_year >= 3 & this_year <= 20) {15} else {14} # Account 409.1
  taxes3_row = if(this_year >= 3 & this_year <= 20) {16} else {15} # Account 409.1
  net_op_inc_row = if(this_year >= 3 & this_year <= 20) {26} else {24}
  taxadj.1_row = if(this_year >= 3 & this_year <= 20) {17} else {16} # account (410.1), add
  taxadj.2_row = if(this_year >= 3 & this_year <= 20) {18} else {17} # account (411.1), subtract
  taxadj.3_row = if(this_year >= 3 & this_year <= 20) {19} else {18} # account (411.4), add
  
  # combine the row numbers
  inc_rows = c(revenue_row, operation_exp_row, maintenance_exp_row, depr_exp1_row, 
               depr_exp2_row, amort_exp1_row, amort_exp2_row, amort_exp3_row, 
               amort_exp4_row, taxes1_row, taxes2_row, taxes3_row, 
               net_op_inc_row, taxadj.1_row, taxadj.2_row, taxadj.3_row)
  cols = c("respondent_id", "report_year", "row_number", "current_yr_total")
  
  # subset the income sheet data to the appropriate rows and columns
  inc = inc[row_number %in% inc_rows, ..cols]
  
  # zero-out the fake deprec_exp2 value for years prior to 2003
  inc[row_number == 22, "current_yr_total"] = 0
  
  # change the row numbers to names identifying the variables
  inc$name = character(nrow(inc))
  inc[row_number == revenue_row,"name"] = "revenue"
  inc[row_number == operation_exp_row,"name"] = "operation_exp"
  inc[row_number == maintenance_exp_row,"name"] = "maintenance_exp"
  inc[row_number == depr_exp1_row,"name"] = "depr_exp.1"
  inc[row_number == depr_exp2_row,"name"] = "depr_exp.2" # after 2003 only
  inc[row_number == amort_exp1_row,"name"] = "amort_exp.1"
  inc[row_number == amort_exp2_row,"name"] = "amort_exp.2"
  inc[row_number == amort_exp3_row,"name"] = "amort_exp.3"
  inc[row_number == amort_exp4_row,"name"] = "amort_exp.4"
  inc[row_number == taxes1_row,"name"] = "taxes.1"
  inc[row_number == taxes2_row,"name"] = "taxes.2"
  inc[row_number == taxes3_row,"name"] = "taxes.3"
  inc[row_number == net_op_inc_row,"name"] = "net_op_inc" # useful for validation
  inc[row_number == taxadj.1_row,"name"] = "taxadj.1"
  inc[row_number == taxadj.2_row,"name"] = "taxadj.2"
  inc[row_number == taxadj.3_row,"name"] = "taxadj.3"
  
  inc$row_number = NULL # clean up
  
  # Manually observations for utilities who have repeated observations in certain years
  # There are 12 instances of duplicates, based on the years & variables I am using
    # Instance 1: 1996, Respondent_ID 55, two taxes.1 ----
      if (this_year == 96) {
        # Separate out problem utility
        inc.prob = inc[respondent_id == 55]
        inc = inc[respondent_id != 55]
        
        # Remove the duplicate value
        inc.prob = inc.prob[!duplicated(name)]
        
        # Bind back onto inc
        inc = rbind(inc, inc.prob)
        
        # clean up
        rm(inc.prob)
      }
  
    # Instance 2: 1997, Respondent_ID 154, two revenues and net_operating_income ----
      if (this_year == 97) {
        # Separate out problem utility
        inc.prob = inc[respondent_id == 154]
        inc = inc[respondent_id != 154]
        
        # Second observation = 0; keep the first instance
        inc.prob = inc.prob[-(which(name == "revenue" & current_yr_total == 0))]
        inc.prob = inc.prob[-(which(name == "net_op_inc" & current_yr_total == 0))]
        
        # Bind back onto inc
        inc = rbind(inc, inc.prob)
        
        # clean up
        rm(inc.prob)
      }
    # Instance 3: 2000, Respondent_ID 189, two net_op_inc ----
      if (this_year == 00) {
        # Separate out problem utility
        inc.prob = inc[respondent_id == 189]
        inc = inc[respondent_id != 189]
        
        # the first instance = 0, keep the second
        inc.prob = inc.prob[-which((current_yr_total == 0 & name == "net_op_inc"))]
        
        
        # Bind back onto inc
        inc = rbind(inc, inc.prob)
        
        # clean up
        rm(inc.prob)
      }
    # Instance 4: 2003, Respondent_ID 7, two taxes.2 ----
      if (this_year == 03) {
        # Separate out problem utility
        inc.prob = inc[respondent_id == 7]
        inc = inc[respondent_id != 7]
        
        # values are equivalent --> Keep the first row
        inc.prob = inc.prob[!duplicated(name)]
        
        # Bind back onto inc
        inc = rbind(inc, inc.prob)
        
        # clean up
        rm(inc.prob)
      }
    # Instance 5: 2006, Respondent_ID 175, two depr_exp.2 ----
      if (this_year == 06) {
        # Separate out problem utility
        inc.prob = inc[respondent_id == 175]
        inc = inc[respondent_id != 175]
        
        # values differ 
        # checking the PDF for Toledo: the second row is correct (427)
        inc.prob = inc.prob[!(which(current_yr_total == -62 & name == "depr_exp.2"))]
        
        # Bind back onto inc
        inc = rbind(inc, inc.prob)
        
        # clean up
        rm(inc.prob)
      }
    # Instance 6: 2010, Respondent_ID 189, two depr_exp.1 ----
    if (this_year == 10) {
      # Separate out problem utility
      inc.prob = inc[respondent_id == 189]
      inc = inc[respondent_id != 189]
      
      # Values are different, check PDF
      # AEP North Texas, second row is correct
      inc.prob = inc.prob[! which(current_yr_total == 12347306 & name == "depr_exp.1")]
      
      # Bind back onto inc
      inc = rbind(inc, inc.prob)
      
      # clean up
      rm(inc.prob)
    }
    # Instance 7: 2011, Respondent_ID 135, two taxes.2 ----
      if (this_year == 11) {
        # Separate out problem utility
        inc.prob = inc[respondent_id == 135]
        inc = inc[respondent_id != 135]
        
        # Two different values, check PDF
        # PECO Energy Company
        # Second value is correct
        inc.prob = inc.prob[!(which(name == "taxes.2" & current_yr_total == 8581670))]
        
        # Bind back onto inc
        inc = rbind(inc, inc.prob)
        
        # clean up
        rm(inc.prob)
      }
    # Instance 8: 2013, Respondent_ID 437, two revenue ----
      if (this_year == 13) {
        # Separate out problem utility
        inc.prob = inc[respondent_id == 437]
        inc = inc[respondent_id != 437]
        
        # check PDF
        # AEP West Virginia Transmission Company, Inc.
        # second observation is correct
        inc.prob = inc.prob[! (which(name == "revenue" & current_yr_total == 6692))]
        
        # Bind back onto inc
        inc = rbind(inc, inc.prob)
        
        # clean up
        rm(inc.prob)
      }
    # Instance 9: 2013, Respondent_ID 88, two taxadj.2 ----
      if (this_year == 13) {
        # Separate out problem utility
        inc.prob = inc[respondent_id == 88]
        inc = inc[respondent_id != 88]
        
        # check PDF
        #  Louisville Gas and Electric Company
        # Second row is correct
        inc.prob = inc.prob[! which(name == "taxadj.2" & current_yr_total == 24567612)]
        
        # Bind back onto inc
        inc = rbind(inc, inc.prob)
        
        # clean up
        rm(inc.prob)
      }
    # Instance 10: 2018, Respondent_ID 322, two operation_exp ----
      if (this_year == 18) {
        # Separate out problem utility
        inc.prob = inc[respondent_id == 322]
        inc = inc[respondent_id != 322]
        
        # check PDF
        #  South Central MCN LLC
        # Second row is correct
        inc.prob = inc.prob[! which(name == "operation_exp" & current_yr_total == 3002992)]
        
        # Bind back onto inc
        inc = rbind(inc, inc.prob)
        
        # clean up
        rm(inc.prob)
      }
    # Instance 11: 2019, Respondent_ID 23, two maintenance_exp ----
      if (this_year == 19) {
        # Separate out problem utility
        inc.prob = inc[respondent_id == 23]
        inc = inc[respondent_id != 23]
        
        # check PDF
        #  rows are equivalent, remove duplicates
        inc.prob = inc.prob[! duplicated(name)]
        
        # Bind back onto inc
        inc = rbind(inc, inc.prob)
        
        # clean up
        rm(inc.prob)
      }
    # Instance 12: 2020, Respondent_ID 438, two maintenance_exp ----
      if (this_year == 20) {
        # Separate out problem utility
        inc.prob = inc[respondent_id == 438]
        inc = inc[respondent_id != 438]
        
        # check PDF
        # AEP Ohio Transmission Company, Inc.
        # second row is correct
        inc.prob = inc.prob[! which(name == "maintenance_exp" & current_yr_total == 1032909)]
        
        # Bind back onto inc
        inc = rbind(inc, inc.prob)
        
        # clean up
        rm(inc.prob)
      }
  
  # reshape the data ----
  inc = as.data.table(pivot_wider(inc, names_from = "name", values_from = "current_yr_total"))
  
  # add the sub-categories together for depreciation, amortization and taxes
  # recode any NA's to 0's
  inc[is.na(depr_exp.1), "depr_exp.1"] = 0
  inc[is.na(depr_exp.2), "depr_exp.2"] = 0
  inc[is.na(amort_exp.1), "amort_exp.1"] = 0
  inc[is.na(amort_exp.2), "amort_exp.2"] = 0
  inc[is.na(amort_exp.3), "amort_exp.3"] = 0
  inc[is.na(amort_exp.4), "amort_exp.4"] = 0
  inc[is.na(taxes.1), "taxes.1"] = 0
  inc[is.na(taxes.2), "taxes.2"] = 0
  inc[is.na(taxes.3), "taxes.3"] = 0
  inc[is.na(taxadj.1), "taxadj.1"] = 0
  inc[is.na(taxadj.2), "taxadj.2"] = 0
  inc[is.na(taxadj.3), "taxadj.3"] = 0
  
  # create new columns
  # income taxes + other taxes + deferred provision - credit + income tax credit adjustment = net taxes owed that year
  inc = inc[, `:=`(depr_exp = depr_exp.1 + depr_exp.2,
                   amort_exp = amort_exp.1 + amort_exp.2 + amort_exp.3 + amort_exp.4,
                   net_taxes = taxes.1 + taxes.2 + taxes.3 + taxadj.1 - taxadj.2 + taxadj.3)]
  
  # remove the sub-categories
  inc[,c("depr_exp.1", "depr_exp.2", "amort_exp.1", "amort_exp.2", "amort_exp.3", "amort_exp.4", 
         "taxes.1", "taxes.2", "taxes.3", "taxadj.1", "taxadj.2", "taxadj.3")] = NULL
  
  # read in ID - Utility Name crosswalk (specific to each year) and merge on
  names = read.delim2(paste0("./data/raw/f1_respondent_id", this_year, ".txt"), 
                      header = TRUE, sep = ",")
  names = as.data.table(names)
  
  inc = merge(inc, names[,c("respondent_id", "respondent_name")], by = "respondent_id",
              all.x = TRUE)
  
  # bind results to outer matrix
  results.inc = rbind(results.inc, inc)
}

# clean up
rm(inc, 
   amort_exp1_row, amort_exp2_row, amort_exp3_row, amort_exp4_row,
   cols, depr_exp1_row, depr_exp2_row, i, inc_rows,
   maintenance_exp_row, net_op_inc_row, operation_exp_row,
   revenue_row, taxadj.1_row, taxadj.2_row, taxadj.3_row,
   taxes1_row, taxes2_row, taxes3_row, this_year)

# ------------------------------------------------------------------------------
# Save results
fwrite(results.inc, "./data/created/income_sheet.csv")
